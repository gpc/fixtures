package grails.fixture

class MockFixture extends AbstractFixture {
        
    def createBuilder() {
        new MockFixtureBuilder(applicationContext, this.class.classLoader)
    }

}