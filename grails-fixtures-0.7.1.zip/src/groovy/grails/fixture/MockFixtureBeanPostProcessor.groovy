package grails.fixture

import org.codehaus.groovy.grails.commons.DefaultGrailsDomainClass
import org.springframework.context.support.ResourceBundleMessageSource
import org.apache.commons.io.FilenameUtils
import grails.test.MockUtils

class MockFixtureBeanPostProcessor extends AbstractFixtureBeanPostProcessor {
    
    def getDomainClass(clazz) {
        new DefaultGrailsDomainClass(clazz)
    }
    
    def getMessageSource() {
		def baseNames = []
        def messageResources = this.parentCtx.getResources("**/WEB-INF/grails-app/i18n/*.properties")?.toList()
        messageResources?.each {
			def baseName = FilenameUtils.getBaseName(it.filename)
			baseName = StringUtils.substringBefore(baseName, "_") // trims possible locale specification
			baseNames << "WEB-INF/grails-app/i18n/" + baseName
		}
		baseNames = baseNames.unique()
        new ResourceBundleMessageSource(basenames: baseNames.toArray())
    }
    
    def postProcessBeforeInitialization(Object bean, String beanName) {
        if (!MockUtils.TEST_INSTANCES.containsKey(bean.class)) {
            MockUtils.mockDomain(bean.class)
        }
        super.postProcessBeforeInitialization(bean, beanName)
    }
}