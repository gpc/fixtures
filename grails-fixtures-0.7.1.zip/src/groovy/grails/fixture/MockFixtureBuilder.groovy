package grails.fixture

import org.springframework.context.ApplicationContext
import org.codehaus.groovy.grails.commons.spring.RuntimeSpringConfiguration

class MockFixtureBuilder extends AbstractFixtureBuilder {

    public MockFixtureBuilder(ApplicationContext parent,ClassLoader classLoader) {
        super(parent, classLoader)
    }
    
    protected RuntimeSpringConfiguration createRuntimeSpringConfiguration(ApplicationContext parent, ClassLoader classLoader) {
        new MockFixtureBuilderRuntimeSpringConfiguration(parent, classLoader)
    }
    
}