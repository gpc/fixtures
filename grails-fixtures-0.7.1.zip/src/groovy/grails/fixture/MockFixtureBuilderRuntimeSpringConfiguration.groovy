package grails.fixture

import org.springframework.context.ApplicationContext

class MockFixtureBuilderRuntimeSpringConfiguration extends AbstractFixtureBuilderRuntimeSpringConfiguration {

    public MockFixtureBuilderRuntimeSpringConfiguration(ApplicationContext parent, ClassLoader classLoader) {
        super(parent, classLoader)
    }
        
    def createBeanPostProcessor(parentCtx) {
        new MockFixtureBeanPostProcessor(parentCtx: parentCtx)
    }
}