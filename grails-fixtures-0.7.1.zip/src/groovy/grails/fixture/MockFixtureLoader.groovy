package grails.fixture

class MockFixtureLoader extends AbstractFixtureLoader {
    
    def createFixture() {
        new MockFixture()
    }
    
    static load(fixture) {
        new MockFixtureLoader().load(fixture)
    }
}